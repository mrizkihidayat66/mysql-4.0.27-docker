rm -f $MYSQL_TEST_DIR/var/master-data/master.info
rm -f $MYSQL_TEST_DIR/var/master-data/*-bin.*
rm -f $MYSQL_TEST_DIR/var/master-data/*.index

